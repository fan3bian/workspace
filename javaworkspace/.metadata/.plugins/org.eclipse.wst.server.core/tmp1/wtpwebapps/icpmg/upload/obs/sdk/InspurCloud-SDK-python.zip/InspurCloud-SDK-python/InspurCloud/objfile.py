#coding:utf-8

import re
import sys
import base64
import os
import socket
import mimetypes
from xml.etree import ElementTree
from email.utils import formatdate
from hashlib import md5
from InspurCloud.objmultiupload import InspurCloud_ObjMultiUpload

class ResponseItem(object):
	def __init__(self):
		self.status = 0
		self.server = "NULL"
		self.connection = "NULL"
		self.objectcount = "NULL"
		self.bytesused = "NULL"
		self.date = "NULL"
		self.contenttype = "NULL"
		self.contentlength = 0
		self.body = "NULL"

class InspurCloud_Objfile(object):
	def __init__(self,bucket = None):
		self.bucket = bucket
		self.connect = bucket.connect
		self.method = None
		self.auth_path = '/'
		self.key = None
		self.fp = None
		self.response = ResponseItem()
		self.blockSize = 1024*1024*5
		self.header = dict()
		self.header['User-Agent'] = 'InspurCloud Python/2.7'
		self.header['Content-Type'] = 'application/octet-stream'
		self.header['date'] = formatdate(usegmt=True)
		self.header['InspurCloud-ChannelType'] = 'SDK'
		self.header['InspurCloud-ClientIP'] = socket.gethostbyname(socket.gethostname())
		self.header['InspurCloud-UserName'] = 'SDK'

		if len(self.bucket.bucket_name) == 0:
			print "bucket name is None"
			sys.exit()

	def __getMD5(self):
		if self.data is None or len(self.data) == 0:
			print "file is None"
			return 0

		hash_obj = md5()
		hash_obj.update(self.data)
		base64_digest = base64.encodestring(hash_obj.digest())
		if base64_digest[-1] == '\n':
			base64_digest = base64_digest[0:-1]
		return base64_digest

	def __putfile(self):
		self.fp = open(self.local_file, "rb")
		try:
			pos = self.fp.tell()
		except IOError:
			pos = None

		self.method = 'PUT'
		self.auth_path = "/%s/%s"%(self.bucket.bucket_name,self.key)
		self.data = self.fp.read(self.totallen)
		self.contentType = mimetypes.guess_type(self.local_file)[0]

		self.header['Content-MD5'] = self.__getMD5()
		self.header['EXPECT'] = '100-Continue'
		if self.contentType is not None and len(self.contentType) != 0:
			self.header['Content-Type'] = self.contentType
		self.header['Content-Length'] = len(self.data)
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, self.data, self.header)
		finally:
			self.fp.close()
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

	def __putmultifile(self):
		self.fp = open(self.local_file, "rb")
		try:
			pos = self.fp.tell()
		except IOError:
			pos = None

		self.contentType = mimetypes.guess_type(self.local_file)[0]
		if self.contentType is None or len(self.contentType) == 0:
			self.contentType = 'application/octet-stream'

		mt = InspurCloud_ObjMultiUpload(self.bucket,self.key)
		uploads = mt.GetAllUploadId()
		if len(uploads) == 0:
			chunkid = 1
			uploadid = mt.GetNewUploadId()
			leftlen = self.totallen

			while leftlen > 0:
				if leftlen >= self.blockSize:
					self.data = self.fp.read(self.blockSize)
				else:
					self.data = self.fp.read(leftlen)
				datamd5 = self.__getMD5()
				mt.UploadPart(self.data,self.contentType,datamd5,uploadid,chunkid)
				print "%s.%s.%s"%(uploadid,datamd5,chunkid)
				leftlen = leftlen - len(self.data)
				chunkid = chunkid + 1

			mt.GetAllUploadPart(uploadid)
			mt.CompleteUpload(uploadid)
		elif len(uploads) == 1:
			uploadid = uploads[0]
			existparts = mt.GetAllUploadPart(uploadid)
			chunknum = int((self.totallen + self.blockSize -1)/(self.blockSize))
			chunkid = 1
			while chunkid <= chunknum:
				partid  = chunkid
				if existparts.has_key(str(partid)) == False:
					self.fp.seek((chunkid-1)*self.blockSize)
					if chunkid == chunknum:
						self.data = self.fp.read()
					else:
						self.data = self.fp.read(self.blockSize)
					datamd5 = self.__getMD5()
					mt.UploadPart(self.data,self.contentType,datamd5,uploadid,chunkid)
					print "%s.%s.%s"%(uploadid,datamd5,chunkid)
				chunkid = chunkid + 1

			mt.GetAllUploadPart(uploadid)
			mt.CompleteUpload(uploadid)
		else:
			uploadnum = len(uploads)
			while uploadnum > 1:
				mt.CancelUpload(uploads[uploadnum-1])
				uploadnum = uploadnum -1
			uploadid = uploads[0]
			existparts = mt.GetAllUploadPart(uploadid)
			chunknum = int((self.totallen + self.blockSize -1)/(self.blockSize))
			chunkid = 1
			while chunkid <= chunknum:
				partid  = chunkid
				if existparts.has_key(str(partid)) == False:
					self.fp.seek((chunkid-1)*self.blockSize)
					if chunkid == chunknum:
						self.data = self.fp.read()
					else:
						self.data = self.fp.read(self.blockSize)
					datamd5 = self.__getMD5()
					mt.UploadPart(self.data,self.contentType,datamd5,uploadid,chunkid)
					print "%s.%s.%s"%(uploadid,datamd5,chunkid)
				chunkid = chunkid + 1

			mt.GetAllUploadPart(uploadid)
			mt.CompleteUpload(uploadid)

	def set_contents_from_filename(self,local_file):
		if local_file is None or len(local_file) == 0:
			print "local file is None"
			sys.exit()
		if self.key is None or len(self.key) == 0:
			self.key = local_file

		self.local_file = local_file
		self.totallen = os.path.getsize(self.local_file)
		if self.totallen <= self.blockSize:
			self.__putfile()
		else:
			self.__putmultifile()

	def get_contents_to_filename(self,local_file):
		if local_file is None or len(local_file) == 0:
			print "local file is None"
			sys.exit()
		if self.key is None or len(self.key) == 0:
			print "key is None"
			sys.exit()

		self.local_file = local_file
		self.fp = open(self.local_file, "wb")

		self.method = 'GET'
		self.auth_path = "/%s/%s"%(self.bucket.bucket_name,self.key)
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.contentlength = res.getheader('content-length')
			self.response.body = res.read(4096)
			self.bodylen = 0
			while len(self.response.body) != 0:
				self.bodylen = self.bodylen + len(self.response.body)
				self.fp.write(self.response.body)
				self.response.body = res.read(4096)
			self.fp.close()
			if self.bodylen != int(self.response.contentlength):
				print "get file uncomplete"
				sys.exit()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "content-length     : [%s]"%self.response.contentlength
				sys.exit()
