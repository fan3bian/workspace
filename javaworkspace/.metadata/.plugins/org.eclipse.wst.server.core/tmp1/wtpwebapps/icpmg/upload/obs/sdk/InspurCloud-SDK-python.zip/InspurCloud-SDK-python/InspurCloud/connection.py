#coding:utf-8

import httplib
import base64
import hmac
import re
from hashlib import sha1 as sha
from email.utils import formatdate
from InspurCloud.bucket import InspurCloud_Bucket

try:
	unicode
except NameError:
	def _is_unicode(x):
		return 0
else:
	def _is_unicode(x):
		return isinstance(x, unicode)

qsa_of_interest = [ 'acl', 'cors', 'defaultObjectAcl', 'location', 'logging',
										'partNumber', 'policy', 'requestPayment', 'torrent',
										'versioning', 'versionId', 'versions', 'website',
										'uploads', 'uploadId', 'response-content-type',
										'response-content-language', 'response-expires',
										'response-cache-control', 'response-content-disposition',
										'response-content-encoding', 'delete', 'lifecycle',
										'tagging', 'restore','storageClass','websiteConfig','compose']

_hexdig = '0123456789ABCDEFabcdef'
_hextochr = dict((a + b, chr(int(a + b, 16)))
							for a in _hexdig for b in _hexdig)
_asciire = re.compile('([\x00-\x7f]+)')

def InspurCloud_Unquote(s):
	"""InspurCloud_Unquote('abc%20def') -> 'abc def'."""
	if _is_unicode(s):
		if '%' not in s:
			return s
		bits = _asciire.split(s)
		res = [bits[0]]
		append = res.append
		for i in range(1, len(bits), 2):
			append(unquote(str(bits[i])).decode('latin1'))
			append(bits[i + 1])
		return ''.join(res)

	bits = s.split('%')
	# fastpath
	if len(bits) == 1:
		return s
	res = [bits[0]]
	append = res.append
	for item in bits[1:]:
		try:
			append(_hextochr[item[:2]])
			append(item[2:])
		except KeyError:
			append('%')
			append(item)
	return ''.join(res)

def unquote_v(nv):
	if len(nv) == 1:
		return nv
	else:
		return (nv[0], InspurCloud_Unquote(nv[1]))

class InspurCloud_Connect(object):
	def __init__(self,InspurCloud_Host=None,InspurCloud_AccessKey=None,InspurCloud_SecretKey=None):
		"""
		:type InspurCloud_Host: string
		:param InspurCloud_Host: The IP to use when  connect to InspurCloud

		:type InspurCloud_AccessKey: string
		:param InspurCloud_AccessKey: The access key to use when connect to InspurCloud

		:type InspurCloud_SecretKey: string
		:param InspurCloud_SecretKey: The secret key to use when connect to InspurCloud
		"""
		self.host = InspurCloud_Host
		self.access_key = InspurCloud_AccessKey
		self.secret_key = InspurCloud_SecretKey
		self.connect = httplib.HTTPConnection('%s:80'%self.host)

	def gettoken(self,clientIP):
		tokenvalue = "TEST"
		headertoken = dict()
		conntoken = httplib.HTTPConnection('%s:9999'%self.host)
		headertoken['User-Agent'] = 'InspurCloud Python/2.7'
		headertoken['Content-Type'] = 'application/octet-stream'
		headertoken['date'] = formatdate(usegmt=True)
		headertoken['OS-ChannelType'] = 'SDK'
		pathtoken = '/tokenManager/gen?accessKey=%s&clientIP=%s&userName=SDK&channel=1'%(self.access_key,clientIP)
		conntoken.request('GET', pathtoken, '', headertoken)
		restoken = conntoken.getresponse()
		if restoken.status == 200:
			tokenvalue = restoken.read()
		conntoken.close()
		return tokenvalue

	def b64_hmac(self,method,auth_path,header):
		string_to_sign = self.__canonical_string(method,auth_path,header)
		new_hmac = hmac.new(self.secret_key,digestmod=sha)
		new_hmac.update(string_to_sign)
		auth = "AWS %s:%s" % (self.access_key, base64.encodestring(new_hmac.digest()).strip())
		return auth

	def __canonical_string(self,method, path, headers):
		interesting_headers = {}
		for key in headers:
			lk = key.lower()
			if headers[key] is not None and (lk in ['content-md5', 'content-type', 'date'] or lk.startswith('x-amz')):
				interesting_headers[lk] = str(headers[key]).strip()

		# these keys get empty strings if they don't exist
		if 'content-type' not in interesting_headers:
			interesting_headers['content-type'] = ''
		if 'content-md5' not in interesting_headers:
			interesting_headers['content-md5'] = ''

		sorted_header_keys = sorted(interesting_headers.keys())

		buf = "%s\n" % method
		for key in sorted_header_keys:
			val = interesting_headers[key]
			if key.startswith('x-amz'):
				buf += "%s:%s\n" % (key, val)
			else:
				buf += "%s\n" % val

		# don't include anything after the first ? in the resource...
		# unless it is one of the QSA of interest, defined above
		t = path.split('?')
		buf += t[0]

		if len(t) > 1:
			qsa = t[1].split('&')
			qsa = [a.split('=', 1) for a in qsa]
			qsa = [unquote_v(a) for a in qsa if a[0] in qsa_of_interest]
			if len(qsa) > 0:
				qsa.sort(cmp=lambda x, y: cmp(x[0], y[0]))
				qsa = ['='.join(a) for a in qsa]
				buf += '?'
				buf += '&'.join(qsa)

		return buf

	def HTTPrequest(self,method,auth_path,data,header):
		self.connect.request(method, auth_path, data, header)

	def HTTPresponse(self):
		return self.connect.getresponse()

	def HTTPreconnect(self):
		if self.connect != None:
			self.connect.close()
			self.connect = None
		self.connect = httplib.HTTPConnection('%s:80'%self.host)

	def close(self):
		if self.connect != None:
			self.connect.close()
			self.connect = None

	def create_bucket(self,bucket_name = None,permission_name = None):
		self.bucket_class = InspurCloud_Bucket(self,'HEAD')
		return self.bucket_class.InspurCloud_CreateBucket('PUT',bucket_name,permission_name)

	def delete_bucket(self,bucket_name = None):
		self.bucket_class = InspurCloud_Bucket(self,'HEAD')
		return self.bucket_class.InspurCloud_DeleteBucket('DELETE',bucket_name)

	def get_all_buckets(self):
		self.bucket_class = InspurCloud_Bucket(self,'HEAD')
		return self.bucket_class.InspurCloud_ListAllBucket('GET')

	def get_bucket(self,bucket_name = None):
		self.bucket_class = InspurCloud_Bucket(self,'HEAD',bucket_name)
		return self.bucket_class
