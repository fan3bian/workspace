#coding:utf-8

import re
import sys
import base64
import os
import socket
import mimetypes
from xml.etree import ElementTree
from email.utils import formatdate
from hashlib import md5

class ResponseItem(object):
	def __init__(self):
		self.status = 0
		self.server = "NULL"
		self.connection = "NULL"
		self.objectcount = "NULL"
		self.bytesused = "NULL"
		self.date = "NULL"
		self.contenttype = "NULL"
		self.contentlength = 0
		self.etag = "NULL"
		self.body = "NULL"

class InspurCloud_ObjMultiUpload(object):
	def __init__(self,bucket = None,key = None):
		self.bucket = bucket
		self.key = key
		self.connect = bucket.connect
		self.method = None
		self.auth_path = '/'
		self.comxml = ""
		self.response = ResponseItem()
		self.header = dict()
		self.header['User-Agent'] = 'InspurCloud Python/2.7'
		self.header['Content-Type'] = 'application/octet-stream'
		self.header['date'] = formatdate(usegmt=True)
		self.header['InspurCloud-ChannelType'] = 'SDK'
		self.header['InspurCloud-ClientIP'] = socket.gethostbyname(socket.gethostname())
		self.header['InspurCloud-UserName'] = 'SDK'

		if len(self.bucket.bucket_name) == 0:
			print "bucket name is None"
			sys.exit()
		if len(self.key) == 0:
			print "key name is None"
			sys.exit()

	def GetNewUploadId(self):
		self.method = 'POST'
		self.auth_path = '/%s/%s?uploads'%(self.bucket.bucket_name,self.key)
		self.header['Content-Length'] = 0
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

		try:
			bodyroot = ElementTree.fromstring(self.response.body)
			xmlns = re.match('\{.*\}', bodyroot.tag)
			namespace = xmlns.group(0)
			for child_of_root in bodyroot:
				if child_of_root.tag != '%sUploadId'%namespace:
					continue
				else:
					uploadid = child_of_root.text
			return uploadid

		except Exception, e:
			print "Error:cannot parse xml"
			sys.exit()

	def GetAllUploadId(self):
		self.method = 'GET'
		self.auth_path = '/%s/?uploads'%self.bucket.bucket_name
		self.header['Content-Length'] = 0
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

		try:
			uploads = []
			bodyroot = ElementTree.fromstring(self.response.body)

			for child_of_root in bodyroot:
				if child_of_root.tag != 'Upload':
					continue
				else:
					for element in child_of_root:
						if element.tag == 'Key':
							key = element.text
						elif element.tag == 'UploadId':
							uploadid = element.text
						else:
							continue
					if key == self.key:
						uploads.append(uploadid)
			return uploads
		except Exception, e:
			print "Error:cannot parse xml"
			sys.exit()

	def GetAllUploadPart(self,uploadid = None):
		if len(uploadid) == 0:
			print "uploadid is None"
			sys.exit()
		self.method = 'GET'
		self.auth_path = '/%s/%s?uploadId=%s'%(self.bucket.bucket_name,self.key,uploadid)
		self.header['Content-Length'] = 0
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()
		try:
			bodyroot = ElementTree.fromstring(self.response.body)
			xmlns = re.match('\{.*\}', bodyroot.tag)
			namespace = xmlns.group(0)
			partdata = dict()
			self.comxml = '<CompleteMultipartUpload>\n'
			for child_of_root in bodyroot:
				if child_of_root.tag != '%sPart'%namespace:
					continue
				else:
					for element in child_of_root:
						if element.tag == '%sPartNumber'%namespace:
							partnum = element.text
						elif element.tag == '%sETag'%namespace:
							etag = element.text
						else:
							continue
					self.comxml += '  <Part>\n'
					self.comxml += '    <PartNumber>%s</PartNumber>\n' % partnum
					self.comxml += '    <ETag>%s</ETag>\n' % etag
					self.comxml += '  </Part>\n'
					partdata[partnum] = etag
			self.comxml += '</CompleteMultipartUpload>'
			return partdata

		except Exception, e:
			print "Error:cannot parse xml"
			sys.exit()

	def UploadPart(self,data,datatype,datamd5,uploadid,partnum):
		if len(data) == 0:
			print "data is None"
			sys.exit()
		if len(datamd5) == 0:
			print "data md5 is None"
			sys.exit()
		if len(uploadid) == 0:
			print "uploadid is None"
			sys.exit()
		if len(datatype) == 0:
			print "datatype is None"
			sys.exit()
		self.method = 'PUT'
		self.auth_path = '/%s/%s?uploadId=%s&partNumber=%d'%(self.bucket.bucket_name,self.key,uploadid,partnum)
		self.header['Content-MD5'] = datamd5
		self.header['EXPECT'] = '100-Continue'
		self.header['Content-Type'] = datatype
		self.header['Content-Length'] = len(data)
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, data, self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.contentlen = res.getheader('content-length')
			self.response.etag       = res.getheader('etag')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "content-length     : [%s]"%self.response.contentlen
				print "etag               : [%s]"%self.response.etag
				print "body               : [%s]"%self.response.body
				sys.exit()

	def CompleteUpload(self,uploadid):
		if len(uploadid) == 0:
			print "uploadid is None"
			sys.exit()
		if len(self.comxml) == 0:
			print "self.comxml is None"
			sys.exit()
		self.method = 'POST'
		self.auth_path = '/%s/%s?uploadId=%s'%(self.bucket.bucket_name,self.key,uploadid)
		self.header['Content-Length'] = len(self.comxml)
		self.header['Content-Type'] = 'text/xml'
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, self.comxml, self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

	def CancelUpload(self,uploadid):
		if len(uploadid) == 0:
			print "uploadid is None"
			sys.exit()
		self.method = 'DELETE'
		self.auth_path = '/%s/%s?uploadId=%s'%(self.bucket.bucket_name,self.key,uploadid)
		self.header['Content-Length'] = 0
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 204:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()
