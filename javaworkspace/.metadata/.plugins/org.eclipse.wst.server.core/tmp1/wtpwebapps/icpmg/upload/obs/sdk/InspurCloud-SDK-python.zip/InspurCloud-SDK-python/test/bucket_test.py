#coding:utf-8
from InspurCloud.connection import InspurCloud_Connect

host = '172.23.4.106'
access_key = 'CSICY0J6WP4PBOGO4CFE'
secret_key = 'vUACwVqHYvJNuVQnhly87fpGEhmlFQ7AT37+3TiL'

conn = InspurCloud_Connect(
				InspurCloud_Host = host,
				InspurCloud_AccessKey = access_key,
				InspurCloud_SecretKey = secret_key,
				)


#����Ͱ
def create_bucket(bucket_name,permission):
	'''
	:type bucket_name: string
	:param bucket_name: The bucket name when create bucket.

	:type permission: string
	:param permission: The permission type when create the permission of this bucket.
	Note that the value is private or public-read
	'''
	conn.create_bucket(bucket_name)

#��ѯ�û�������Ͱ
def getallbucket():
	bucketlist = conn.get_all_buckets()
	for line in bucketlist:
		print line.Name,line.CreationDate

#ɾ��ָ��Ͱ
def del_bucket(bucket_name):
	'''
	:type bucket_name: string
	:param bucket_name: The bucket name when delete the bucket.
	'''
	conn.delete_bucket(bucket_name)

#Ͱ��Ȩ��(˽��ͰȨ��:private;����ͰȨ��:public-read)
def changepermission(bucket_name,permission):
	'''
	:type bucket_name: string
	:param bucket_name: The bucket name when change the permission of this bucket.

	:type permission: string
	:param permission: The permission type when change the permission of this bucket.
	Note that the value is private or public-read
	'''
	b = conn.get_bucket(bucket_name)
	b.set_acl(permission)
	permissionlist=b.get_acl()
	for permission in permissionlist:
		print permission
