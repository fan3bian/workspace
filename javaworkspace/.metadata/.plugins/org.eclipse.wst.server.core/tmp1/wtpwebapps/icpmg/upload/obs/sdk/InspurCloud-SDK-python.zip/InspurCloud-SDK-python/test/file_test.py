#coding:utf-8

from InspurCloud.connection import InspurCloud_Connect
from InspurCloud.objfile import InspurCloud_Objfile

host = '172.23.4.106'
access_key = 'CSICY0J6WP4PBOGO4CFE'
secret_key = 'vUACwVqHYvJNuVQnhly87fpGEhmlFQ7AT37+3TiL'

conn = InspurCloud_Connect(
				InspurCloud_Host = host,
				InspurCloud_AccessKey = access_key,
				InspurCloud_SecretKey = secret_key,
				)

#��ѯͰ�������ļ�
def get_bucket(bucket_name):
	'''
	:type bucket_name: string
	:param bucket_name: The bucket name when list file from the bucket.
	'''
	b = conn.get_bucket(bucket_name)
	filelist = b.list()
	for line in filelist:
		print line.keyvalue.decode('utf-8'),line.sizevalue,line.datevalue

#ɾ��ָ��Ͱ��ָ���ļ�
def del_bucket(bucket_name,key_name):
	'''
	:type bucket_name: string
	:param bucket_name: The bucket name when delete key from a specified bucket.

	:type key_name: string
	:param key_name: The key name when delete key from a specified bucket.
	'''
	b = conn.get_bucket(bucket_name)
	b.delete_key(key_name)

#�޸�ĳ�ļ�����
def rename(key_newname,key_oldname,bucket_name):
	'''
	:type key_newname: string
	:param key_newname: The new key name when the key name changed.

	:type key_oldname: string
	:param key_oldname: The old key name when the key name changed.

	:type bucket_name: string
	:param bucket_name: The bucket name when the key name changed.
	'''
	b = conn.get_bucket(bucket_name)
	b.copy_key(key_newname,key_oldname)
	b.delete_key(key_oldname)

#�ϴ��ļ���ָ��Ͱ
def putfile(key_name,local_name,bucket_name):
	'''
	:type key_name: string
	:param key_name: The key name when upload files to a specified bucket.

	:type local_name: string
	:param local_name: The name of the file to be uploaded. Note that the include file path

	:type bucket_name: string
	:param bucket_name: Bucket name when uploading files.
	'''
	b = conn.get_bucket(bucket_name)
	k = InspurCloud_Objfile(b)
	k.key = key_name
	k.set_contents_from_filename(local_name)

#����ָ��Ͱָ���ļ�
def getfile(key_name,local_name,bucket_name):
	'''
	:type key_name: string
	:param key_name: The key name when download files from a specified bucket.

	:type local_name: string
	:param local_name: The name of the file to be downloaded. Note that the include file path

	:type bucket_name: string
	:param bucket_name: Bucket name when downloading files.
	'''
	b = conn.get_bucket(bucket_name)
	key = b.lookup(key_name)
	if key:
		key.get_contents_to_filename(local_name)
