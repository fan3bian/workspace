#coding:utf-8

import re
import sys
import socket
from xml.etree import ElementTree
from email.utils import formatdate
from InspurCloud.objfile import InspurCloud_Objfile

class ResponseItem(object):
	def __init__(self):
		self.status = 0
		self.server = "NULL"
		self.connection = "NULL"
		self.objectcount = "NULL"
		self.bytesused = "NULL"
		self.date = "NULL"
		self.contenttype = "NULL" 
		self.body = "NULL"

class FileItem(object):
	def __init__(self):
		self.keyvalue = "NULL"
		self.datevalue = "NULL"
		self.sizevalue = "NULL"

class BucketItem(object):
	def __init__(self):
		self.Name = "NULL"
		self.CreationDate = "NULL"

class InspurCloud_Bucket(object):
	def __init__(self,connect,method = None,bucket_name = None):
		self.connect = connect
		self.auth_path = '/'
		self.method = method
		self.bucket_name = bucket_name
		self.response = ResponseItem()
		self.header = dict()
		self.header['User-Agent'] = 'InspurCloud Python/2.7'
		self.header['Content-Type'] = ''
		self.header['date'] = formatdate(usegmt=True)
		self.header['InspurCloud-ChannelType'] = 'SDK'
		self.header['InspurCloud-ClientIP'] = socket.gethostbyname(socket.gethostname())
		self.header['InspurCloud-UserName'] = 'SDK'

		if self.bucket_name is not None:
			self.auth_path = "/%s/"%self.bucket_name
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

	def InspurCloud_CreateBucket(self,method = None, bucket_name = None,permission_name = None):
		self.bucket_name = bucket_name
		self.method = method
		self.auth_path = "/%s"%self.bucket_name
		self.header['x-amz-acl'] = permission_name
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

	def InspurCloud_DeleteBucket(self,method = None, bucket_name = None):
		self.bucket_name = bucket_name
		self.method = method
		self.auth_path = "/%s/"%self.bucket_name
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 204:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

	def InspurCloud_ListAllBucket(self,method):
		self.method = method
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

		try:
			bucketlist = []
			bodyroot = ElementTree.fromstring(self.response.body)
			xmlns = re.match('\{.*\}', bodyroot.tag)
			namespace = xmlns.group(0)
			for child_of_root in bodyroot:
				if child_of_root.tag != '%sBuckets'%namespace:
					continue
				for Bucket in child_of_root:
					bucketitem = BucketItem()
					for element in Bucket:
						if element.tag == '%sName'%namespace:
							bucketitem.Name = element.text
						elif element.tag == '%sCreationDate'%namespace:
							bucketitem.CreationDate = element.text
					bucketlist += [bucketitem]
			return bucketlist
		except Exception, e:
			print "Error:cannot parse xml"

	def set_acl(self,permission_name = None):
		self.method = 'PUT'
		if permission_name not in ['private', 'public-read']:
			print "permission error"
			sys.exit()

		self.header['x-amz-acl'] = permission_name
		self.auth_path = "/%s/?acl"%self.bucket_name
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

	def get_acl(self):
		self.method = 'GET'
		self.auth_path = "/%s/?acl"%(self.bucket_name)
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

		try:
			permissionlist = []
			bodyroot = ElementTree.fromstring(self.response.body)
			xmlns = re.match('\{.*\}', bodyroot.tag)
			namespace = xmlns.group(0)
			for child_of_root in bodyroot:
				if child_of_root.tag != '%sAccessControlList'%namespace:
					continue
				for Grant in child_of_root:
					for element in Grant:
						if element.tag != '%sPermission'%namespace:
							continue
						permissionlist += [element.text]
			return permissionlist
		except Exception, e:
			print "Error:cannot parse xml"

	def list(self):
		self.method = 'GET'
		if self.bucket_name is None or len(self.bucket_name) == 0:
			print "bucket name is None"
			sys.exit()
		self.auth_path = "/%s/"%(self.bucket_name)
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

		try:
			filelist = []
			bodyroot = ElementTree.fromstring(self.response.body)
			xmlns = re.match('\{.*\}', bodyroot.tag)
			namespace = xmlns.group(0)
			for child_of_root in bodyroot:
				fileItem = FileItem()
				if child_of_root.tag != '%sContents'%namespace:
					continue
				for element in child_of_root:
					if element.tag == '%sKey'%namespace:
						fileItem.keyvalue = element.text
					elif element.tag == '%sLastModified'%namespace:
						fileItem.datevalue = element.text
					elif element.tag == '%sSize'%namespace:
						fileItem.sizevalue = element.text
					else:
						continue
				filelist += [fileItem]
			return filelist
		except Exception, e:
			print "Error:cannot parse xml"

	def delete_key(self,key_name = None):
		self.method = 'DELETE'
		if self.bucket_name is None or len(self.bucket_name) == 0:
			print "bucket name is None"
			sys.exit()
		if key_name is None or len(key_name) == 0:
			print "key_name is None"
			sys.exit()

		self.auth_path = "/%s/%s"%(self.bucket_name,key_name)
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 204:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

	def copy_key(self,key_newname = None,key_oldname = None):
		self.method = 'PUT'
		if self.bucket_name is None or len(self.bucket_name) == 0:
			print "bucket name is None"
			sys.exit()
		if key_newname is None or len(key_newname) == 0:
			print "key_newname is None"
			sys.exit()
		if key_oldname is None or len(key_oldname) == 0:
			print "key_oldname is None"
			sys.exit()

		self.header['x-amz-storage-class'] = "STANDARD"
		self.header['x-amz-metadata-directive'] = "COPY"
		self.header['x-amz-copy-source'] = "%s/%s"%(self.bucket_name,key_oldname)
		self.auth_path = "/%s/%s"%(self.bucket_name,key_newname)
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

	def lookup(self,key_name):
		self.method = 'GET'
		if self.bucket_name is None or len(self.bucket_name) == 0:
			print "bucket name is None"
			sys.exit()
		self.auth_path = "/%s/"%(self.bucket_name)
		self.header['InspurCloud-Token'] = self.connect.gettoken(self.header['InspurCloud-ClientIP'])
		self.header['Authorization'] = self.connect.b64_hmac(self.method,self.auth_path,self.header)

		try:
			self.connect.HTTPrequest(self.method, self.auth_path, '', self.header)
		finally:
			res = self.connect.HTTPresponse()
			self.response.status = res.status
			self.response.server = res.getheader('server')
			self.response.connection = res.getheader('connection')
			self.response.objectcount = res.getheader('x-rgw-object-count')
			self.response.bytesused = res.getheader('x-rgw-bytes-used')
			self.response.date = res.getheader('date')
			self.response.contenttype = res.getheader('content-type')
			self.response.body = res.read()
			if res.status != 200:
				print "status             : [%d]"%self.response.status
				print "server             : [%s]"%self.response.server
				print "connection         : [%s]"%self.response.connection
				print "x-rgw-object-count : [%s]"%self.response.objectcount
				print "x-rgw-bytes-used   : [%s]"%self.response.bytesused
				print "date               : [%s]"%self.response.date
				print "content-type       : [%s]"%self.response.contenttype
				print "body               : [%s]"%self.response.body
				sys.exit()

		key_attr = []
		try:
			bodyroot = ElementTree.fromstring(self.response.body)
			xmlns = re.match('\{.*\}', bodyroot.tag)
			namespace = xmlns.group(0)
			for child_of_root in bodyroot:
				if child_of_root.tag != '%sContents'%namespace:
					continue
				for element in child_of_root:
					if element.tag == '%sKey'%namespace:
						keyvalue = element.text
						key_attr.append(keyvalue)
					elif element.tag == '%sLastModified'%namespace:
						datevalue = element.text
					elif element.tag == '%sSize'%namespace:
						sizevalue = element.text
					else:
						continue
		except Exception, e:
			print "Error:cannot parse xml"

		if key_name not in key_attr:
			print "key name is not exist"
			sys.exit()
		else:
			k = InspurCloud_Objfile(self)
			k.key = key_name
			return k
