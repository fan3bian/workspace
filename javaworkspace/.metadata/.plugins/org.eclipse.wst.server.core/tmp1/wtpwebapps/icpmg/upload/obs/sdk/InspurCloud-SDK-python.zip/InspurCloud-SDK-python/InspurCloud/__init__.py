# -*- coding: utf-8 -*-

"""
InspurCloud SDK for python
"""

__version__ = '1.0.0'
